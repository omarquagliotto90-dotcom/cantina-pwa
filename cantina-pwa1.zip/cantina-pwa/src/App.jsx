import { useState, useRef, useEffect } from "react";

// ─── Supabase client (no dipendenze esterne — REST API diretta) ───────────────
const SB_URL = "https://etbrgdldduadgbulasmy.supabase.co";
const SB_KEY = "sb_publishable_OKQmpbDBpDbPTOmKclMwZw_fRtg1KKR";

const sb = {
  async get(table) {
    const r = await fetch(`${SB_URL}/rest/v1/${table}?order=created_at.asc`, {
      headers: { apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}`, "Content-Type": "application/json" }
    });
    if (!r.ok) return [];
    return r.json();
  },
  async insert(table, row) {
    const r = await fetch(`${SB_URL}/rest/v1/${table}`, {
      method: "POST",
      headers: { apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}`, "Content-Type": "application/json", Prefer: "return=representation" },
      body: JSON.stringify(row)
    });
    if (!r.ok) return null;
    const data = await r.json();
    return data[0] || null;
  },
  async delete(table, column, value) {
    await fetch(`${SB_URL}/rest/v1/${table}?${column}=eq.${value}`, {
      method: "DELETE",
      headers: { apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}` }
    });
  }
};

// ─── M3 Token System (seed: #7B1D1D vinaccia) ────────────────────────────────
const M3 = {
  primary:                 "#9B3535",
  onPrimary:               "#FFFFFF",
  primaryContainer:        "#FFDAD6",
  onPrimaryContainer:      "#410002",
  secondary:               "#775652",
  onSecondary:             "#FFFFFF",
  secondaryContainer:      "#FFDAD6",
  onSecondaryContainer:    "#2C1512",
  surface:                 "#FFF8F7",
  onSurface:               "#201A19",
  surfaceVariant:          "#F5DEDD",
  onSurfaceVariant:        "#534341",
  surfaceContainer:        "#F5EDEC",
  surfaceContainerHigh:    "#EFE7E6",
  surfaceContainerHighest: "#E9E1E0",
  outline:                 "#857370",
  outlineVariant:          "#D8C2BF",
  error:                   "#BA1A1A",
};

const TIPO = {
  "Rosso fermo":    { container: "#FFDAD6", onContainer: "#410002", indicator: "#9B3535", label: "🍷" },
  "Bianco fermo":   { container: "#FBDFA6", onContainer: "#261A00", indicator: "#705C2E", label: "🥂" },
  "Orange":         { container: "#FFE0B2", onContainer: "#4A2800", indicator: "#E65100", label: "🍊" },
  "Spumante":       { container: "#D3E4FF", onContainer: "#001C3B", indicator: "#2B5EA7", label: "✨" },
  "Spumante rosso": { container: "#FFD7F5", onContainer: "#390048", indicator: "#8B2FC9", label: "🫧" },
  "Sidro":          { container: "#C8E6C9", onContainer: "#002106", indicator: "#2E7D32", label: "🍐" },
};

const FILTERS = ["Tutti", "Rosso fermo", "Bianco fermo", "Orange", "Spumante", "Spumante rosso", "Sidro"];

// ─── Slow Wine 2025 premi ─────────────────────────────────────────────────────
// chiocciola: premio alla cantina | bottiglia: premio al vino specifico
const SW_CANTINA_CHIOCCIOLA = new Set([
  "Pieropan", "Ca' dei Zago", "Bele Casel", "Miotto", "Malibràn", "Occhipinti",
]);
// { produttore|vino: true } per vini premiati con bottiglia
const SW_VINO_BOTTIGLIA = new Set([
  "Bertani|Valpolicella Classico Superiore Ognisanti 2022", // Top Wine
  "Ca' dei Zago|Vigneto Mariarosa",                         // Top Wine
  "Bele Casel|Asolo Prosecco Superiore Extra Brut 2023",    // Top Wine
]);
// Helper: la cantina ha chiocciola?
const hasCantina = (produttore) => SW_CANTINA_CHIOCCIOLA.has(produttore);

// ─── Dataset vini — schede tecniche da fonti ufficiali ───────────────────────
const WINES_DATA = [
  // ── ABBAZIA DI NOVACELLA ─────────────────────────────────────────────────────
  // Fonte: kloster-neustift.it | Valle Isarco DOC Sylvaner
  { id: 2,  produttore: "Abbazia di Novacella",    vino: "Sylvaner",
    annata: "n.d.",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 18,
    vitigno: "Sylvaner 100%",
    macerazione: "Nessuna — pressatura soffice pneumatica",
    fermentazione: "75% in acciaio inox a 17-19°C, 25% in botti di acacia 50 hl",
    malolattica: "No",
    note: "Vigneti a 650-750 m s.l.m., suoli morenici di mica-scisto. Affinamento 6 mesi sulle fecce fini. Alcol 13%, acidità 6,0 g/l. Produzione 880 anni di tradizione abbaziale." },

  // ── BERTANI ──────────────────────────────────────────────────────────────────
  // Fonte: negoziodelvino.it, bibes.it | Amarone DOCG 2015
  { id: 45, produttore: "Bertani",                 vino: "Amarone della Valpolicella DOCG",
    annata: "2015",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 130,
    vitigno: "Corvina Veronese 80%, Rondinella 20%",
    macerazione: "20 gg a 4-5°C (post-appassimento 120 gg su arèle di bambù)",
    fermentazione: "Lenta ~30 gg in vasche di cemento a max 18°C, lieviti indigeni",
    malolattica: "Sì, spontanea",
    note: "Tenuta Novare, Valpolicella Classica. Appassimento 120 gg senza controllo T/umidità. Affinamento 7 anni in botti di rovere di Slavonia 50-100 hl. Alcol 15%. Wine of the Year 2024 James Suckling (100/100). Longevo fino a 40+ anni.", slowVinoBott: true },

  // ── BELE CASEL ───────────────────────────────────────────────────────────────
  // Fonte: belecasel.com | Col Fondo e Caranto
  { id: 34, produttore: "Bele Casel",              vino: "Col Fondo",
    annata: "2023",  tipologia: "Spumante",       bottiglie: 5, prezzo: 14,
    vitigno: "Glera + vecchie varietà locali (Bianchetta Trevigiana, Perera)",
    macerazione: "Nessuna — pressatura soffice pneumatica, decantazione statica",
    fermentazione: "In acciaio inox; rifermentazione spontanea in bottiglia (primavera), senza sboccatura",
    malolattica: "No",
    note: "Vigneti a Monfumo (TV) su suolo marnoso-argilloso grigio. Affinamento 8 mesi in acciaio senza filtrazione né solfiti aggiunti. Lieviti sul fondo come conservante naturale. Agitare dolcemente prima di servire." },

  { id: 35, produttore: "Bele Casel",              vino: "Caranto",
    annata: "2020",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 28,
    vitigno: "Raboso Piave 100%",
    macerazione: "20-25 gg sulle bucce",
    fermentazione: "In botte grande, lieviti indigeni",
    malolattica: "Sì",
    note: "Caranto: il nome del suolo argilloso tipico della Marca Trevigiana. Raboso Piave autoctono, austero, elevatissima acidità naturale e struttura tannica. Grande longevità in bottiglia." },

  // ── BIONDO JEO ───────────────────────────────────────────────────────────────
  // Fonte: quattrocalici.it, impetodivino.it | Vitigni Trevigiani MC e Frizzante
  { id: 16, produttore: "Biondo Jeo",              vino: "Metodo Classico Brut Nature",
    annata: "n.d.",  tipologia: "Spumante",       bottiglie: 1, prezzo: 18,
    vitigno: "Verdiso, Perera, Glera (blend tradizionale Trevigiano)",
    macerazione: "Nessuna",
    fermentazione: "In acciaio; rifermentazione in bottiglia (Metodo Classico), remuage manuale",
    malolattica: "Parziale",
    note: "Colline Trevigiane. Metodo Classico da vitigni autoctoni della tradizione veneta. Dosaggio zero. Perlage fine e persistente, complessità da lieviti." },

  { id: 17, produttore: "Biondo Jeo",              vino: "Vino Frizzante Bianco",
    annata: "n.d.",  tipologia: "Spumante",       bottiglie: 1, prezzo: 12,
    vitigno: "Verdiso, Perera, Glera (blend trevigiano)",
    macerazione: "Nessuna",
    fermentazione: "In acciaio; rifermentazione naturale in bottiglia",
    malolattica: "No",
    note: "Versione frizzante da vitigni autoctoni trevigiani. Stile fresco, beverino, con deposito naturale sul fondo." },

  // ── BRESOLIN ─────────────────────────────────────────────────────────────────
  { id: 36, produttore: "Bresolin",                vino: "DiFondo Colli Trevigiani IGT Bio",
    annata: "2021",  tipologia: "Spumante",       bottiglie: 1, prezzo: 16,
    vitigno: "Glera 100%",
    macerazione: "Nessuna",
    fermentazione: "In acciaio con lieviti indigeni; rifermentazione spontanea in bottiglia",
    malolattica: "No",
    note: "Col fondo biologico certificato. Colline Trevigiane. Zero filtrazioni, zero solfiti aggiunti. Stile artigianale, deposito lieviti sul fondo." },

  // ── CA' DEI ZAGO ─────────────────────────────────────────────────────────────
  // Fonte: decanto.it, wivood.com, etilika.it | San Pietro in Barbozza, Valdobbiadene
  { id: 31, produttore: "Ca' dei Zago",            vino: "Colli Trevigiani IGT",
    annata: "2023",  tipologia: "Spumante",       bottiglie: 7, prezzo: 16,
    vitigno: "Glera + piccole percentuali di Verdiso, Bianchetta Trevigiana, Perera",
    macerazione: "Breve macerazione sulle bucce 3-4 giorni in cemento",
    fermentazione: "Fermentazione spontanea con lieviti indigeni in vasche di cemento; riposo in acciaio inox durante l'inverno; rifermentazione spontanea in bottiglia in primavera",
    malolattica: "No",
    note: "6,5 ha a San Pietro in Barbozza, 250-400 m s.l.m. Viti 50-60 anni. Biodinamica, no prodotti di sintesi mai usati. La temperatura esterna funge da stabilizzatore naturale. Declassato da DOCG a IGT per scelta di stile. Gradazione 11%." },

  { id: 32, produttore: "Ca' dei Zago",            vino: "100a Vendemmia",
    annata: "2024",  tipologia: "Spumante",       bottiglie: 3, prezzo: 18,
    vitigno: "Glera 100%",
    macerazione: "Breve contatto con le fecce",
    fermentazione: "Fermentazione spontanea in cemento con lieviti indigeni; rifermentazione in bottiglia",
    malolattica: "No",
    note: "Edizione speciale per la centesima vendemmia della famiglia Zanatta (dal 1924). Stessa tecnica ancestrale del col fondo classico ma da selezione speciale di uve." },

  { id: 33, produttore: "Ca' dei Zago",            vino: "Valdobbiadene MC Dosaggio Zero",
    annata: "2023",  tipologia: "Spumante",       bottiglie: 6, prezzo: 22,
    vitigno: "Glera 100%",
    macerazione: "Nessuna",
    fermentazione: "Fermentazione in bottiglia con lieviti indigeni (Metodo Classico); remuage manuale; sboccatura senza dosaggio",
    malolattica: "No",
    note: "Rarissimo Metodo Classico da produttore specializzato in col fondo. Complessità da lieviti intatta. Christian Zanatta porta il metodo ancestrale verso la versione MC dosaggio zero. Uno dei pochi in Valdobbiadene." },

  // ── CHIUSA GRANDE ────────────────────────────────────────────────────────────
  { id: 41, produttore: "Chiusa Grande",           vino: "Lune Vere Trebbiano IGT",
    annata: "2022",  tipologia: "Orange",         bottiglie: 1, prezzo: 20,
    vitigno: "Trebbiano d'Abruzzo 100%",
    macerazione: "Macerazione prolungata sulle bucce",
    fermentazione: "In cemento con lieviti indigeni",
    malolattica: "No",
    note: "Abruzzo. Trebbiano vinificato in orange, vitigno di grande longevità nella versione macerata. Chiusa Grande è riferimento per i vini naturali abruzzesi." },

  // ── COLLE MORA ───────────────────────────────────────────────────────────────
  // Fonte: collemora.it, fisarmonza.it | Sagrantino Passito DOCG
  { id: 42, produttore: "Colle Mora",              vino: "Il Curato Sagrantino Passito",
    annata: "2019",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 35,
    vitigno: "Sagrantino 100%",
    macerazione: "~20 gg a contatto con le bucce in acciaio (post-appassimento 3 mesi su graticci)",
    fermentazione: "In vasche di acciaio inox; post malolattica affinamento in legno grande rovere",
    malolattica: "Sì",
    note: "Piccola cantina familiare (6 ha), Montefalco. Simone e Michela: no diserbante, sovescio, rame e zolfo. Appassimento 3 mesi in ambiente ventilato. Vino meditativo, longevità eccezionale. 20.000 bottiglie totali annue." },

  // ── DOMAINE POTINET-AMPEAU ────────────────────────────────────────────────────
  { id: 29, produttore: "Domaine Potinet-Ampeau",  vino: "Bourgogne Aligoté Vieille Vigne",
    annata: "2016",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 25,
    vitigno: "Aligoté 100%",
    macerazione: "Nessuna",
    fermentazione: "In botti di Borgogna 228 L (Pièces), lieviti indigeni",
    malolattica: "Sì",
    note: "Piccolo domaine familiare di Meursault. Aligoté da vigne vecchie, raro da trovare in questa qualità. Fermentazione e affinamento in botti borgognone tradizionali." },

  // ── FATTORIA MILZIADE ANTANO ─────────────────────────────────────────────────
  // Fonte: enotecalombardi.com, alvidoc.it | Montefalco Rosso Riserva DOC
  { id: 47, produttore: "Fattoria Milziade Antano",vino: "Montefalco Rosso Riserva DOC",
    annata: "2015",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 30,
    vitigno: "Sangiovese 70%, Sagrantino 15%, Merlot 15%",
    macerazione: "20-25 gg",
    fermentazione: "In vasche di acciaio inox con lieviti indigeni; malolattica in acciaio",
    malolattica: "Sì",
    note: "Bevagna (PG), Fattoria Colleallodole. Fondata dal Cav. Milziade Antano, figura chiave nella storia del Sagrantino. Affinamento 14 mesi in botti di rovere. Riserva potente, tannica. Alcol 15,5%." },

  // ── FONTALE ──────────────────────────────────────────────────────────────────
  { id: 46, produttore: "Fontale",                 vino: "Giorno Rosso",
    annata: "n.d.",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 10,
    vitigno: "Sangiovese 85%, Colorino 15%",
    macerazione: "10 gg sulle bucce",
    fermentazione: "In cemento con lieviti indigeni",
    malolattica: "Sì",
    note: "Toscana. Blend di Sangiovese con Colorino (vitigno toscano da colore), stile fresco e beverino quotidiano. Produttore artigianale." },

  // ── FRANCESCO TOLLADOR ────────────────────────────────────────────────────────
  { id: 12, produttore: "Francesco Tollador",      vino: "Fellalba Valdobbiadene Extra Brut",
    annata: "n.d.",  tipologia: "Spumante",       bottiglie: 1, prezzo: 18,
    vitigno: "Glera 90%, Verdiso 10%",
    macerazione: "Nessuna",
    fermentazione: "In acciaio; rifermentazione in bottiglia con lieviti indigeni (metodo ancestrale)",
    malolattica: "No",
    note: "Produttore artigianale di Valdobbiadene, Colline di Conegliano. Col fondo di rara finezza e precisione. Extra Brut: secco con finale minerale." },

  // ── GIANNITESSARI ────────────────────────────────────────────────────────────
  // Fonte: giannitessari.wine, vinipiwi.it | Rebellis 2019 — VITIGNO CORRETTO
  { id: 30, produttore: "Giannitessari",           vino: "Rebellis",
    annata: "2019",  tipologia: "Orange",         bottiglie: 1, prezzo: 22,
    vitigno: "Solaris 100% (vitigno PIWI resistente, incrocio Riesling × Pinot Grigio)",
    macerazione: "5-7 gg sulle bucce con lieviti indigeni in vasi aperti",
    fermentazione: "Chiusura della fermentazione e affinamento 12 mesi in anfore di terracotta",
    malolattica: "No",
    note: "San Giovanni Ilarione, Lessinia (VR), 550 m s.l.m. Vigneto 1,5 ha, pergola semplice, 70 hl/ha. Solaris: vitigno PIWI (Pilzwiderstandfähig) resistente ai funghi. Prima azienda veneta iscritta a PIWI International. No trattamenti fitosanitari. Colore dorato, note agrumate e spezie dolci." },

  // ── GIULIO PASOTTI ────────────────────────────────────────────────────────────
  { id: 18, produttore: "Giulio Pasotti",          vino: "Valpolicella DOC",
    annata: "2019",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 15,
    vitigno: "Corvina 65%, Rondinella 25%, Molinara 10%",
    macerazione: "8-10 gg sulle bucce",
    fermentazione: "In cemento con lieviti indigeni",
    malolattica: "Sì",
    note: "Piccolo produttore artigianale della Valpolicella Classica. Blend tradizionale delle tre varietà autoctone veronesi. Stile genuino e diretto." },

  // ── LABORATORIO AGRICOLO ─────────────────────────────────────────────────────
  // Produttore artigianale con distribuzione molto limitata, senza sito web strutturato
  { id: 22, produttore: "Laboratorio Agricolo",    vino: "Albino",
    annata: "n.d.",  tipologia: "Orange",         bottiglie: 2, prezzo: 20,
    vitigno: "Johanniter 100% (vitigno PIWI resistente, incrocio con Riesling)",
    macerazione: "Lunga macerazione sulle bucce in contenitore chiuso",
    fermentazione: "Spontanea con lieviti indigeni, anfora o cemento",
    malolattica: "Sì",
    note: "Produttore sperimentale sui vitigni resistenti PIWI. Johanniter: incrocio resistente ai funghi che non richiede trattamenti. Orange wine di rara originalità nel panorama italiano." },

  { id: 26, produttore: "Laboratorio Agricolo",    vino: "KWr",
    annata: "n.d.",  tipologia: "Sidro",          bottiglie: 2, prezzo: 15,
    vitigno: "Kiwi (Actinidia deliciosa) 100%",
    macerazione: "Macerazione su polpa di kiwi in tino aperto per 30 gg",
    fermentazione: "Spontanea con lieviti indigeni in acciaio",
    malolattica: "No",
    note: "Sidro di kiwi completamente fermentato. KWr = Kiwi Wine Rosé. Prodotto unicissimo nel panorama italiano delle bevande fermentate artigianali." },

  { id: 25, produttore: "Laboratorio Agricolo",    vino: "Legno",
    annata: "n.d.",  tipologia: "Spumante rosso", bottiglie: 2, prezzo: 18,
    vitigno: "Cabernet Cortis 100% (vitigno PIWI resistente)",
    macerazione: "15-20 gg sulle bucce",
    fermentazione: "Rifermentazione in bottiglia con lieviti indigeni; affinamento in legno antico",
    malolattica: "Sì",
    note: "Spumante rosso ancestrale da vitigno resistente PIWI. Passaggio in legno vecchio per complessità senza cessione di tannini del legno." },

  { id: 24, produttore: "Laboratorio Agricolo",    vino: "R=V/I Vino Bianco Resistente",
    annata: "n.d.",  tipologia: "Bianco fermo",   bottiglie: 2, prezzo: 18,
    vitigno: "Souvignier Gris 100% (vitigno PIWI resistente)",
    macerazione: "Breve contatto con le bucce",
    fermentazione: "In acciaio con lieviti indigeni",
    malolattica: "No",
    note: "Nome ispirato alla legge di Ohm (R=V/I). Souvignier Gris: incrocio resistente ai funghi. Approccio sperimentale sui vitigni resistenti PIWI." },

  { id: 23, produttore: "Laboratorio Agricolo",    vino: "Vino Bianco",
    annata: "n.d.",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 16,
    vitigno: "Blend di vitigni PIWI resistenti",
    macerazione: "Nessuna",
    fermentazione: "In acciaio con lieviti indigeni",
    malolattica: "No",
    note: "Cuvée base del Laboratorio da blend di varietà resistenti ai funghi. Stile fresco e beverino con approccio naturale." },

  // ── LE CASELLE ────────────────────────────────────────────────────────────────
  { id: 44, produttore: "Le Caselle",              vino: "Falconero",
    annata: "2023",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 12,
    vitigno: "Sangiovese 100%",
    macerazione: "12-15 gg sulle bucce",
    fermentazione: "In cemento con lieviti indigeni",
    malolattica: "Sì",
    note: "Umbria. Sangiovese diretto e fruttato. Piccola realtà artigianale a conduzione familiare." },

  // ── LUNARIA ───────────────────────────────────────────────────────────────────
  { id: 21, produttore: "Lunaria",                 vino: "Ramoro Pinot Grigio",
    annata: "n.d.",  tipologia: "Orange",         bottiglie: 1, prezzo: 12,
    vitigno: "Pinot Grigio 100% (vinificato sulle bucce)",
    macerazione: "24-48h sulle bucce — estrazione del colore ramato",
    fermentazione: "In acciaio inox",
    malolattica: "No",
    note: "Abruzzo biologico. Il Ramoro è la versione tradizionale del Pinot Grigio macerato, tipica del Nordest. Il colore rame viene dal contatto con le bucce naturalmente rosa del Pinot Grigio." },

  { id: 20, produttore: "Lunaria",                 vino: "Ruminat Primitivo",
    annata: "n.d.",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 12,
    vitigno: "Montepulciano d'Abruzzo 100%",
    macerazione: "10-12 gg sulle bucce",
    fermentazione: "In acciaio inox a temperatura controllata",
    malolattica: "Sì",
    note: "Abruzzo certificato biologico. Ruminat è il nome del vento locale. Stile fresco, fruttato e beverino. Ottimo rapporto qualità-prezzo." },

  // ── MACULAN ───────────────────────────────────────────────────────────────────
  { id: 13, produttore: "Maculan",                 vino: "Pino & Toi",
    annata: "2024",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 10,
    vitigno: "Pinot Grigio + Tai Bianco (Tocai Friulano)",
    macerazione: "Nessuna",
    fermentazione: "In acciaio inox a temperatura controllata",
    malolattica: "No",
    note: "Breganze DOC. Pino & Toi: blend di Pinot Grigio e Tocai (Tai). Fresco, aromatico, facile beva. Maculan è storico produttore di Breganze." },

  { id: 14, produttore: "Maculan",                 vino: "Vespaiolo",
    annata: "2024",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 12,
    vitigno: "Vespaiolo 100%",
    macerazione: "Nessuna",
    fermentazione: "Metodo Charmat lungo in autoclave",
    malolattica: "No",
    note: "Breganze DOC. Vespaiolo: vitigno autoctono veneto rarissimo, coltivato quasi esclusivamente nell'area di Breganze (VI). Aromi floreali e fruttati, nota amarognola tipica." },

  // ── MALIBRÀN ──────────────────────────────────────────────────────────────────
  { id: 15, produttore: "Malibràn",                vino: "Teatrale Incroci",
    annata: "n.d.",  tipologia: "Spumante rosso", bottiglie: 1, prezzo: 12,
    vitigno: "Raboso Piave 100%",
    macerazione: "Breve macerazione pre-rifermentazione",
    fermentazione: "Rifermentazione in bottiglia (col fondo rosso), lieviti indigeni",
    malolattica: "No",
    note: "Col fondo rosso da Raboso Piave, vitigno autoctono della Marca Trevigiana. Malibràn: cantina con chiocciola Slow Wine 2025. Stile rustico e autentico, tipico del Veneto rurale tradizionale." },

  // ── MIOTTO ────────────────────────────────────────────────────────────────────
  // Fonte: cantinamiotto.it | Colbertaldo di Vidor (TV) — scheda tecnica ufficiale
  { id: 37, produttore: "Miotto",                  vino: "ProFondo Col Fondo",
    annata: "2018",  tipologia: "Spumante",       bottiglie: 1, prezzo: 16,
    vitigno: "Glera 100%, vigneti di proprietà",
    macerazione: "Nessuna — pressatura soffice, illimpidimento statico",
    fermentazione: "In acciaio a 17-19°C; riposo sulle fecce fini con pochi travasi; rifermentazione in bottiglia nelle 2 settimane pre-Pasqua; fermentazione si arresta autonomamente",
    malolattica: "No",
    note: "Colbertaldo di Vidor (TV). Sistema sylvoz e doppio capovolto. Sosta 10-12 mesi in bottiglia. Vino secco, asciutto, finale piacevolmente amarognolo — tipico surlie. Longevo: verticali fino al 2012 ancora tonici. Gradazione 11%." },

  { id: 38, produttore: "Miotto",                  vino: "ProFondo Col Fondo",
    annata: "2019",  tipologia: "Spumante",       bottiglie: 1, prezzo: 16,
    vitigno: "Glera 100%, vigneti di proprietà",
    macerazione: "Nessuna — pressatura soffice, illimpidimento statico",
    fermentazione: "In acciaio a 17-19°C; riposo sulle fecce fini; rifermentazione in bottiglia a primavera",
    malolattica: "No",
    note: "Annata 2019. Bello da confrontare verticalmente con le altre annate. Stile consistente: secco, minerale, finale amarognolo da lieviti." },

  { id: 39, produttore: "Miotto",                  vino: "ProFondo Col Fondo",
    annata: "2020",  tipologia: "Spumante",       bottiglie: 1, prezzo: 16,
    vitigno: "Glera 100%, vigneti di proprietà",
    macerazione: "Nessuna",
    fermentazione: "In acciaio; rifermentazione spontanea in bottiglia a primavera",
    malolattica: "No",
    note: "Annata 2020. Terza delle quattro annate in verticale. I Miotto: 9 ettari a Colbertaldo, 100.000 bottiglie/anno, bestseller nei wine bar naturali di tutta Italia." },

  { id: 40, produttore: "Miotto",                  vino: "ProFondo Col Fondo",
    annata: "2021",  tipologia: "Spumante",       bottiglie: 1, prezzo: 16,
    vitigno: "Glera 100%, vigneti di proprietà",
    macerazione: "Nessuna",
    fermentazione: "In acciaio; rifermentazione spontanea in bottiglia a primavera",
    malolattica: "No",
    note: "Annata 2021, la più recente della verticale. Pronto al consumo ma la longevità è superiore al previsto: le annate vecchie dimostrano 8+ anni di vita in bottiglia." },

  // ── MOVIA ─────────────────────────────────────────────────────────────────────
  // Fonte: carico.io, 8wines.com, winetelling.it | VITIGNO CORRETTO: Friulano (non Ribolla)
  { id: 28, produttore: "Movia",                   vino: "Exto Gredič",
    annata: "2023",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 28,
    vitigno: "Friulano 100% (Tocai Friulano / Sauvignonasse / Green Sauvignon)",
    macerazione: "30 gg sulle bucce (orange wine), con pied de cuve di uve in pre-vendemmia",
    fermentazione: "Fermentazione spontanea in tini di acciaio inox; affinamento 8 mesi negli stessi contenitori",
    malolattica: "Sì, spontanea in contenitore",
    note: "Ceglo, Goriška Brda (Slovenia), al confine con il Collio italiano. Suolo flysch di marna e arenaria, 2 ha, viti 25 anni, Guyot, 5.000 ceppi/ha. Vendemmia tardiva. Biodinamica. Movia fondata nel 1820, oggi Aleš Kristančič. Zero solfiti aggiunti. Solforosa totale 40 mg/l. 16.000 bottiglie." },

  // ── OCCHIPINTI ────────────────────────────────────────────────────────────────
  // Fonte: triplea.it, grandibottiglie.com | SP68 Bianco — VITIGNI CORRETTI
  { id: 27, produttore: "Occhipinti",              vino: "SP68 Bianco",
    annata: "2025",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 27,
    vitigno: "Albanello 40%, Moscato d'Alessandria (Zibibbo) 60%",
    macerazione: "12 gg sulle bucce con rimontaggi e follature giornaliere",
    fermentazione: "Fermentazione spontanea con lieviti indigeni in tini di cemento 85 hl; affinamento 7 mesi negli stessi contenitori; 1 mese in bottiglia senza filtrazione",
    malolattica: "No",
    note: "Vittoria (RG), Contrada Fossa di Lupo. Suolo sabbioso calcareo. 4,5 ha, Guyot, 6.000 ceppi/ha, età media viti 23 anni, 35 hl/ha. Biodinamica. SP68 = Strada Provinciale 68, la strada lungo cui si trovano i vigneti. Solforosa totale 40 mg/l. 20.000 bottiglie.", slowVinoBott: true },

  // ── PERONI VIGNAIOLE ──────────────────────────────────────────────────────────
  { id: 8,  produttore: "Peroni Vignaiole",        vino: 'Trebbiano "Monteitto"',
    annata: "n.d.",  tipologia: "Bianco fermo",   bottiglie: 2, prezzo: 9,
    vitigno: "Trebbiano di Lugana 100%",
    macerazione: "Nessuna",
    fermentazione: "In acciaio inox a temperatura controllata",
    malolattica: "No",
    note: "Montenetto di Brescia. Bianco fresco e diretto. Trebbiano di Lugana nelle colline bresciane." },

  { id: 9,  produttore: "Peroni Vignaiole",        vino: 'Marzemino "Montelungo"',
    annata: "n.d.",  tipologia: "Rosso fermo",    bottiglie: 3, prezzo: 9,
    vitigno: "Marzemino 100%",
    macerazione: "7-10 gg sulle bucce",
    fermentazione: "In acciaio inox con lieviti indigeni",
    malolattica: "Sì",
    note: "Montenetto di Brescia. Marzemino: vitigno bresciano-trentino fresco e fruttato. Citato da Mozart nel Don Giovanni (Atto II: 'Già la mensa è preparata'). Grande bevibilità." },

  { id: 10, produttore: "Peroni Vignaiole",        vino: 'Merlot "Montealbi"',
    annata: "n.d.",  tipologia: "Rosso fermo",    bottiglie: 2, prezzo: 9,
    vitigno: "Merlot 100%",
    macerazione: "7-10 gg sulle bucce",
    fermentazione: "In acciaio inox",
    malolattica: "Sì",
    note: "Montenetto di Brescia. Merlot in stile fresco e beverino, adatto al consumo giovane. Ottimo rapporto qualità-prezzo." },

  // ── PIEROPAN ──────────────────────────────────────────────────────────────────
  // Fonte: pieropan.it — scheda tecnica ufficiale completa
  { id: 1,  produttore: "Pieropan",                vino: "Soave Classico",
    annata: "2024",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 13,
    vitigno: "Garganega 85-90%, Trebbiano di Soave 10-15%",
    macerazione: "Nessuna — pressatura in ambiente protetto con azoto",
    fermentazione: "Fermentazione a bassa temperatura 14-18°C in vasche di cemento vetrificate (tulipe); affinamento 5-9 mesi sulle fecce fini con batonnage manuale fino a dicembre",
    malolattica: "No",
    note: "Soave Classico DOC. Vigneti 100-300 m s.l.m., suoli vulcanici (tufo basaltico). Viti 6-60 anni, Guyot e Pergola Veronese. Raccolta manuale in due fasi (Trebbiano metà settembre, Garganega ottobre). Biologico certificato. 60 ha, 560.000 bottiglie. Alcol 12%, zucchero 3,1 g/l. Awards 2024: Wine Enthusiast 94, Robert Parker 92, Kerin O'Keefe 94." },

  // ── PISTIS SOPHIA ─────────────────────────────────────────────────────────────
  // Fonte: clickwine.it, unconventionalwine.com | David Seccia, Ortona (CH)
  { id: 3,  produttore: "Pistis Sophia",           vino: "Dysnomìa",
    annata: "n.d.",  tipologia: "Bianco fermo",   bottiglie: 1, prezzo: 16,
    vitigno: "Pergolone + Moscatello Selvatico (vitigni autoctoni abruzzesi)",
    macerazione: "20 gg a tino chiuso sulle bucce",
    fermentazione: "Spontanea in cisterna di acciaio inox sulle fecce; nessun travaso; imbottigliamento con chicchi di grano Saragolla (rifermentazione naturale)",
    malolattica: "Spontanea",
    note: "David Seccia, Ortona (CH), C.da San Donato. Pergolone: vitigno autoctono abruzzese quasi estinto, recuperato da Seccia. Dysnomìa = dea del caos (mitologia greca). Zero solfiti aggiunti. Lieviti indigeni. Alcol 13,14%, acidità 6,33 g/l." },

  { id: 4,  produttore: "Pistis Sophia",           vino: "Kriós",
    annata: "n.d.",  tipologia: "Rosso fermo",    bottiglie: 2, prezzo: 18,
    vitigno: "Montepulciano d'Abruzzo 100%",
    macerazione: "15-20 gg sulle bucce, lieviti indigeni",
    fermentazione: "Spontanea in acciaio/cemento; riposo sulle fecce fine senza travasi",
    malolattica: "Spontanea",
    note: "Viti 40-80 anni. Kriós = ariete in greco. Inerbimento tra i filari, calendari lunari. Zero chimica. Deraspatrice, torchio e botti di acciaio/terracotta/legno. Produzione ~500 bottiglie." },

  { id: 6,  produttore: "Pistis Sophia",           vino: "Léon",
    annata: "n.d.",  tipologia: "Rosso fermo",    bottiglie: 2, prezzo: 18,
    vitigno: "Montepulciano d'Abruzzo 100%",
    macerazione: "20-30 gg sulle bucce",
    fermentazione: "Spontanea in cemento; affinamento sulle fecce senza travasi",
    malolattica: "Sì (spontanea)",
    note: "Léon = leone in greco. Macerazione più lunga rispetto al Kriós, maggiore estrazione di tannini e colore. Struttura più imponente." },

  { id: 5,  produttore: "Pistis Sophia",           vino: "Págos",
    annata: "n.d.",  tipologia: "Orange",         bottiglie: 1, prezzo: 22,
    vitigno: "Pergolone + Trebbiano d'Abruzzo (blend variabile per Metodo Solera)",
    macerazione: "Raccolta giugno, ossidazione in vasca aperta 4 mesi; poi diraspatura e macerazione 30 gg sulle bucce",
    fermentazione: "Metodo Solera: blend di annate diverse. Torchiatura in gabbia di rovere; riposo in acciaio fino a maggio/giugno; 1 anno in bottiglia",
    malolattica: "Sì",
    note: "Págos = campo (greco). Il vino più raro e complesso di Seccia. Metodo Solera pluriennale: ogni anno parte del blend rimane per formare la base dell'annata successiva. Note di fiori secchi, albicocca, erbe officinali. Zero solfiti. Gradazione 12,5%." },

  { id: 7,  produttore: "Pistis Sophia",           vino: "Parthéna",
    annata: "n.d.",  tipologia: "Orange",         bottiglie: 2, prezzo: 16,
    vitigno: "Trebbiano d'Abruzzo + Cococciola",
    macerazione: "~3 settimane sulle bucce",
    fermentazione: "Spontanea con lieviti indigeni; affinamento 6 mesi in acciaio sulle fecce",
    malolattica: "Parziale",
    note: "Parthéna = vergine (greco). Orange wine incisivo e poliedrico. Cococciola: vitigno autoctono abruzzese raro, aromi agrumati. Zero solfiti aggiunti." },

  // ── RIZZINI ───────────────────────────────────────────────────────────────────
  // Fonte: enantico.com, golamifa.it | Franciacorta Extra Brut Selezione — single cru
  { id: 11, produttore: "Rizzini",                 vino: "Franciacorta Extra Brut Selezione",
    annata: "2010",  tipologia: "Spumante",       bottiglie: 1, prezzo: 60,
    vitigno: "Chardonnay 100% (single cru, unico vigneto aziendale)",
    macerazione: "Nessuna",
    fermentazione: "Raccolta manuale fine agosto/inizio settembre; pressatura soffice uva intera. 90% in acciaio inox sulle fecce 8 mesi; 10% in barrique di rovere francese usate. Rifermentazione in bottiglia (Metodo Classico). Remuage manuale.",
    malolattica: "Parziale (solo la quota in barrique)",
    note: "Monticelli Brusati (BS). Filosofia 'un unico cru': solo uve del vigneto aziendale. Annata 2010 = Extra Brut 132 mesi sui lieviti (11 anni). Sboccatura senza dosaggio (Extra Brut). Complessità aromatica: crosta di pane, frutta bianca, mineralità. Tra i Franciacorta millesimati con il più lungo affinamento al mondo." },

  // ── SANTORO ───────────────────────────────────────────────────────────────────
  { id: 19, produttore: "Santoro",                 vino: "Negroamaro Puglia IGP",
    annata: "n.d.",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 10,
    vitigno: "Negroamaro 100%",
    macerazione: "10-12 gg sulle bucce",
    fermentazione: "In acciaio inox a temperatura controllata",
    malolattica: "Sì",
    note: "Puglia IGP. Negroamaro: uno dei principali vitigni pugliesi, colore intenso, tannini morbidi, frutto di ciliegia e prugna. Ottimo rapporto qualità-prezzo." },

  // ── TENIMENTI GRIECO ─────────────────────────────────────────────────────────
  { id: 43, produttore: "Tenimenti Grieco",        vino: "200 Metri Tintilia del Molise DOC",
    annata: "2024",  tipologia: "Rosso fermo",    bottiglie: 1, prezzo: 18,
    vitigno: "Tintilia 100%",
    macerazione: "10-12 gg sulle bucce",
    fermentazione: "In acciaio inox a temperatura controllata",
    malolattica: "Sì",
    note: "Molise DOC. Tintilia: vitigno autoctono molisano quasi estinto, recuperato negli anni 2000. Vigna a 200 m s.l.m. Colore rubino intenso, tannini eleganti, finale speziato. Rarità assoluta nel panorama enologico italiano." },
];

// ─── Filter Chip M3 ───────────────────────────────────────────────────────────
function FilterChip({ label, active, onClick }) {
  const t = TIPO[label];
  return (
    <button onClick={onClick} style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      height: 32, padding: active ? "0 12px 0 8px" : "0 12px",
      borderRadius: 8,
      border: active ? "none" : `1px solid ${M3.outline}`,
      background: active ? (t?.container || M3.secondaryContainer) : "transparent",
      color: active ? (t?.onContainer || M3.onSecondaryContainer) : M3.onSurfaceVariant,
      fontSize: 14, fontFamily: "'Roboto', sans-serif", fontWeight: 500,
      letterSpacing: 0.1, cursor: "pointer", whiteSpace: "nowrap",
      transition: "all 0.15s", flexShrink: 0,
    }}>
      {active && <span style={{ fontSize: 13 }}>✓ </span>}
      {t && <span style={{ fontSize: 13 }}>{t.label} </span>}
      {label}
    </button>
  );
}

// ─── Slow Wine Badge ──────────────────────────────────────────────────────────
function SwBadge({ type }) {
  if (type === "chiocciola") return (
    <span title="Cantina premiata Slow Wine 2025" style={{
      fontSize: 13, background: "#E8F5E9", color: "#2E7D32",
      padding: "1px 6px", borderRadius: 4, fontWeight: 600,
      fontFamily: "'Roboto', sans-serif", letterSpacing: 0.1,
    }}>🐌 Chiocciola</span>
  );
  if (type === "bottiglia") return (
    <span title="Vino premiato Slow Wine 2025" style={{
      fontSize: 13, background: "#E3F2FD", color: "#0D47A1",
      padding: "1px 6px", borderRadius: 4, fontWeight: 600,
      fontFamily: "'Roboto', sans-serif", letterSpacing: 0.1,
    }}>🍾 Slow Wine</span>
  );
  return null;
}

// ─── Wine Card ────────────────────────────────────────────────────────────────
function WineCard({ wine, expanded, onToggle, onBevi }) {
  const t = TIPO[wine.tipologia] || TIPO["Bianco fermo"];
  const totalVal = wine.prezzo * wine.bottiglie;
  const cantinaSW = hasCantina(wine.produttore);
  const vinoSW = !!wine.slowVinoBott;

  return (
    <div style={{
      borderRadius: 12,
      border: expanded ? `1px solid ${t.indicator}55` : `1px solid ${M3.outlineVariant}`,
      background: expanded ? M3.surfaceContainerHigh : M3.surface,
      overflow: "hidden",
      transition: "box-shadow 0.2s, border-color 0.2s, background 0.2s",
      boxShadow: expanded ? "0 1px 2px rgba(0,0,0,0.10),0 2px 6px rgba(0,0,0,0.07)" : "0 1px 2px rgba(0,0,0,0.05)",
    }}>
      <div onClick={onToggle} style={{ display: "flex", alignItems: "stretch", minHeight: 68, cursor: "pointer" }}>
        <div style={{ width: 4, flexShrink: 0, background: expanded ? t.indicator : "transparent", transition: "background 0.2s" }} />
        <div style={{ flex: 1, padding: "11px 12px", minWidth: 0 }}>
          <div style={{ fontSize: 10, fontFamily: "'Roboto', sans-serif", fontWeight: 500, letterSpacing: 0.5, color: M3.onSurfaceVariant, textTransform: "uppercase", marginBottom: 1 }}>
            {wine.produttore}
            {cantinaSW && <span style={{ marginLeft: 5, fontSize: 12 }}>🐌</span>}
          </div>
          <div style={{ fontSize: 15, fontFamily: "'Roboto', sans-serif", fontWeight: 500, color: M3.onSurface, lineHeight: 1.3, marginBottom: 5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {wine.vino}
            {vinoSW && <span style={{ marginLeft: 5, fontSize: 12 }}>🍾</span>}
          </div>
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap", alignItems: "center" }}>
            <span style={{ fontSize: 11, padding: "1px 7px", borderRadius: 4, background: t.container, color: t.onContainer, fontFamily: "'Roboto', sans-serif", fontWeight: 500 }}>
              {t.label} {wine.tipologia}
            </span>
            <span style={{ fontSize: 11, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif" }}>{wine.annata}</span>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", justifyContent: "space-between", padding: "11px 12px 11px 6px", flexShrink: 0 }}>
          <span style={{ fontSize: 15, fontWeight: 700, color: M3.primary, fontFamily: "'Roboto', sans-serif" }}>~{totalVal}€</span>
          <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
            <span style={{ fontSize: 11, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif" }}>🍾 {wine.bottiglie}</span>
            <span style={{ fontSize: 17, color: M3.onSurfaceVariant, transform: expanded ? "rotate(180deg)" : "rotate(0)", transition: "transform 0.25s cubic-bezier(0.2,0,0,1)", display: "block", lineHeight: 1 }}>⌄</span>
          </div>
        </div>
      </div>

      {expanded && (
        <div style={{ padding: "0 14px 14px", animation: "expandIn 0.22s cubic-bezier(0.2,0,0,1)" }}>
          <div style={{ height: 1, background: M3.outlineVariant, marginBottom: 12 }} />

          {/* Slow Wine badges */}
          {(cantinaSW || vinoSW) && (
            <div style={{ display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap" }}>
              {cantinaSW && <SwBadge type="chiocciola" />}
              {vinoSW && <SwBadge type="bottiglia" />}
            </div>
          )}

          {/* Stats */}
          <div style={{ display: "flex", gap: 7, marginBottom: 12, flexWrap: "wrap" }}>
            {[{ l: "Prezzo", v: `~${wine.prezzo}€` }, { l: "Bottiglie", v: wine.bottiglie }, { l: "Valore", v: `~${totalVal}€` }].map(s => (
              <div key={s.l} style={{ flex: "1 1 70px", background: M3.surfaceVariant, borderRadius: 10, padding: "9px 10px", textAlign: "center" }}>
                <div style={{ fontSize: 17, fontWeight: 700, color: M3.primary, fontFamily: "'Roboto', sans-serif" }}>{s.v}</div>
                <div style={{ fontSize: 10, color: M3.onSurfaceVariant, textTransform: "uppercase", letterSpacing: 0.4, fontFamily: "'Roboto', sans-serif", marginTop: 1 }}>{s.l}</div>
              </div>
            ))}
          </div>

          {/* Tech grid */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 7, marginBottom: 10 }}>
            {[
              { icon: "🍇", label: "Vitigno", val: wine.vitigno },
              { icon: "⏱", label: "Macerazione", val: wine.macerazione },
              { icon: "🧪", label: "Fermentazione", val: wine.fermentazione },
              { icon: "🔄", label: "Malolattica", val: wine.malolattica },
            ].map(s => (
              <div key={s.label} style={{ background: M3.surfaceContainer, borderRadius: 8, padding: "9px 10px" }}>
                <div style={{ fontSize: 10, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 3 }}>{s.icon} {s.label}</div>
                <div style={{ fontSize: 11, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", lineHeight: 1.4 }}>{s.val}</div>
              </div>
            ))}
          </div>

          {/* Note */}
          <div style={{ background: M3.surfaceContainer, borderRadius: 8, padding: "10px 12px", borderLeft: `3px solid ${t.indicator}`, marginBottom: 12 }}>
            <div style={{ fontSize: 10, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 5 }}>📝 Note</div>
            <div style={{ fontSize: 12, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", lineHeight: 1.6 }}>{wine.note}</div>
          </div>

          <button onClick={(e) => { e.stopPropagation(); onBevi(wine.id); }} style={{
            width: "100%", padding: "10px 16px", borderRadius: 20, border: "none",
            background: M3.primaryContainer, color: M3.onPrimaryContainer,
            fontSize: 14, fontWeight: 500, fontFamily: "'Roboto', sans-serif",
            cursor: "pointer", letterSpacing: 0.1,
          }}>
            🍷 Segna come bevuto
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Modal: Aggiungi Vino ─────────────────────────────────────────────────────
function ModalAggiungi({ onSalva, onAnnulla }) {
  const [modo, setModo] = useState(null); // null | "manuale" | "foto"
  const [form, setForm] = useState({ produttore: "", vino: "", annata: "", tipologia: "Rosso fermo", bottiglie: 1, prezzo: 0, vitigno: "", note: "" });
  const fileRef = useRef();

  const field = (key, label, type = "text", opts = {}) => (
    <div style={{ marginBottom: 12 }}>
      <div style={{ fontSize: 11, color: M3.onSurfaceVariant, textTransform: "uppercase", letterSpacing: 0.4, fontFamily: "'Roboto', sans-serif", marginBottom: 4 }}>{label}</div>
      {opts.select ? (
        <select value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} style={{ width: "100%", padding: "9px 12px", borderRadius: 8, border: `1px solid ${M3.outline}`, background: M3.surfaceContainerHighest, fontSize: 14, fontFamily: "'Roboto', sans-serif", color: M3.onSurface, outline: "none" }}>
          {Object.keys(TIPO).map(t => <option key={t}>{t}</option>)}
        </select>
      ) : (
        <input type={type} value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: type === "number" ? Number(e.target.value) : e.target.value }))}
          style={{ width: "100%", padding: "9px 12px", borderRadius: 8, border: `1px solid ${M3.outline}`, background: M3.surfaceContainerHighest, fontSize: 14, fontFamily: "'Roboto', sans-serif", color: M3.onSurface, outline: "none" }} />
      )}
    </div>
  );

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 60, display: "flex", alignItems: "flex-end", background: "rgba(0,0,0,0.45)" }} onClick={onAnnulla}>
      <div onClick={e => e.stopPropagation()} style={{ width: "100%", background: M3.surface, borderRadius: "28px 28px 0 0", maxHeight: "90vh", overflowY: "auto", padding: "20px 20px 36px", animation: "slideUp 0.3s cubic-bezier(0.2,0,0,1)" }}>
        <div style={{ width: 32, height: 4, background: M3.outlineVariant, borderRadius: 2, margin: "0 auto 18px" }} />
        <div style={{ fontSize: 20, fontWeight: 500, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", marginBottom: 20 }}>
          ➕ Aggiungi vino
        </div>

        {!modo && (
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => setModo("manuale")} style={{ flex: 1, padding: "24px 12px", borderRadius: 16, border: `1px solid ${M3.outlineVariant}`, background: M3.surfaceContainer, cursor: "pointer", textAlign: "center" }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>✏️</div>
              <div style={{ fontSize: 14, fontWeight: 500, color: M3.onSurface, fontFamily: "'Roboto', sans-serif" }}>Inserimento manuale</div>
              <div style={{ fontSize: 12, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", marginTop: 4 }}>Compila i campi a mano</div>
            </button>
            <button onClick={() => fileRef.current?.click()} style={{ flex: 1, padding: "24px 12px", borderRadius: 16, border: `1px solid ${M3.outlineVariant}`, background: M3.surfaceContainer, cursor: "pointer", textAlign: "center" }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>📷</div>
              <div style={{ fontSize: 14, fontWeight: 500, color: M3.onSurface, fontFamily: "'Roboto', sans-serif" }}>Foto etichetta</div>
              <div style={{ fontSize: 12, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", marginTop: 4 }}>Scatta o carica una foto</div>
            </button>
            <input ref={fileRef} type="file" accept="image/*" capture="environment" style={{ display: "none" }}
              onChange={() => setModo("foto")} />
          </div>
        )}

        {modo === "foto" && (
          <div style={{ textAlign: "center", padding: "20px 0" }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🚧</div>
            <div style={{ fontSize: 15, fontWeight: 500, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", marginBottom: 8 }}>Riconoscimento in arrivo</div>
            <div style={{ fontSize: 13, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", marginBottom: 20, lineHeight: 1.5 }}>
              Il riconoscimento automatico dell'etichetta via AI sarà disponibile nella prossima versione. Per ora usa l'inserimento manuale.
            </div>
            <button onClick={() => setModo("manuale")} style={{ padding: "10px 24px", borderRadius: 20, border: "none", background: M3.primaryContainer, color: M3.onPrimaryContainer, fontSize: 14, fontWeight: 500, fontFamily: "'Roboto', sans-serif", cursor: "pointer" }}>
              Inserimento manuale →
            </button>
          </div>
        )}

        {modo === "manuale" && (
          <>
            {field("produttore", "Produttore")}
            {field("vino", "Nome vino")}
            {field("annata", "Annata")}
            {field("tipologia", "Tipologia", "text", { select: true })}
            {field("bottiglie", "N. bottiglie", "number")}
            {field("prezzo", "Prezzo (€/bot.)", "number")}
            {field("vitigno", "Vitigno")}
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 11, color: M3.onSurfaceVariant, textTransform: "uppercase", letterSpacing: 0.4, fontFamily: "'Roboto', sans-serif", marginBottom: 4 }}>Note</div>
              <textarea value={form.note} onChange={e => setForm(p => ({ ...p, note: e.target.value }))} rows={3}
                style={{ width: "100%", padding: "9px 12px", borderRadius: 8, border: `1px solid ${M3.outline}`, background: M3.surfaceContainerHighest, fontSize: 14, fontFamily: "'Roboto', sans-serif", color: M3.onSurface, outline: "none", resize: "vertical" }} />
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setModo(null)} style={{ flex: 1, padding: "11px", borderRadius: 20, border: `1px solid ${M3.outline}`, background: "transparent", color: M3.onSurface, fontSize: 14, fontWeight: 500, fontFamily: "'Roboto', sans-serif", cursor: "pointer" }}>← Indietro</button>
              <button onClick={() => { if (form.produttore && form.vino) onSalva(form); }}
                style={{ flex: 2, padding: "11px", borderRadius: 20, border: "none", background: form.produttore && form.vino ? M3.primary : M3.surfaceContainerHighest, color: form.produttore && form.vino ? M3.onPrimary : M3.onSurfaceVariant, fontSize: 14, fontWeight: 500, fontFamily: "'Roboto', sans-serif", cursor: "pointer" }}>
                Salva in cantina
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Modal: Segna come bevuto ─────────────────────────────────────────────────
function ModalBevi({ wine, onConferma, onAnnulla }) {
  const [nota, setNota] = useState("");
  if (!wine) return null;
  const today = new Date().toLocaleDateString("it-IT", { day: "2-digit", month: "long", year: "numeric" });
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 50, display: "flex", alignItems: "flex-end", background: "rgba(0,0,0,0.4)" }} onClick={onAnnulla}>
      <div onClick={e => e.stopPropagation()} style={{ width: "100%", background: M3.surface, borderRadius: "28px 28px 0 0", padding: "24px 20px 32px", animation: "slideUp 0.3s cubic-bezier(0.2,0,0,1)" }}>
        <div style={{ width: 32, height: 4, background: M3.outlineVariant, borderRadius: 2, margin: "0 auto 20px" }} />
        <div style={{ fontSize: 20, fontWeight: 500, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", marginBottom: 4 }}>🍷 Segna come bevuto</div>
        <div style={{ fontSize: 14, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", marginBottom: 16 }}>{wine.produttore} · {wine.vino} · {wine.annata}</div>
        <div style={{ background: M3.surfaceContainer, borderRadius: 8, padding: "10px 14px", marginBottom: 16, fontSize: 13, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif" }}>
          📅 Data apertura: <strong style={{ color: M3.onSurface }}>{today}</strong>
        </div>
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 11, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.4 }}>Nota di degustazione (opzionale)</div>
          <textarea value={nota} onChange={e => setNota(e.target.value)} placeholder="Come ti è sembrato? Abbinamento, occasione…"
            style={{ width: "100%", minHeight: 70, background: M3.surfaceContainerHighest, border: "none", borderRadius: 8, padding: "10px 12px", fontSize: 14, fontFamily: "'Roboto', sans-serif", color: M3.onSurface, resize: "vertical", outline: "none" }} />
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={onAnnulla} style={{ flex: 1, padding: "11px", borderRadius: 20, border: `1px solid ${M3.outline}`, background: "transparent", color: M3.onSurface, fontSize: 14, fontWeight: 500, fontFamily: "'Roboto', sans-serif", cursor: "pointer" }}>Annulla</button>
          <button onClick={() => onConferma(nota, today)} style={{ flex: 2, padding: "11px", borderRadius: 20, border: "none", background: M3.primary, color: M3.onPrimary, fontSize: 14, fontWeight: 500, fontFamily: "'Roboto', sans-serif", cursor: "pointer" }}>Conferma</button>
        </div>
      </div>
    </div>
  );
}

// ─── Tab: Lista ───────────────────────────────────────────────────────────────
function TabLista({ wines, bevuti, onBevi, onAggiungi, compact }) {
  const [filter, setFilter] = useState("Tutti");
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState(null);

  const bevutiIds = new Set(bevuti.map(b => b.id));
  const filtered = wines
    .filter(w => !bevutiIds.has(w.id))
    .filter(w => filter === "Tutti" || w.tipologia === filter)
    .filter(w => {
      const q = search.toLowerCase();
      return !q || w.produttore.toLowerCase().includes(q) || w.vino.toLowerCase().includes(q) || w.annata.includes(q) || (w.vitigno || "").toLowerCase().includes(q);
    });

  const totalB = filtered.reduce((a, w) => a + w.bottiglie, 0);
  const totalV = filtered.reduce((a, w) => a + w.prezzo * w.bottiglie, 0);

  return (
    <>
      <div style={{ padding: "6px 16px 4px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: M3.surfaceContainerHighest, borderRadius: 28, padding: "7px 14px", height: compact ? 34 : 38, transition: "height 0.3s" }}>
          <span style={{ fontSize: 14, color: M3.onSurfaceVariant }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cerca produttore, vino, vitigno…"
            style={{ flex: 1, background: "none", border: "none", fontSize: 14, color: M3.onSurface, fontFamily: "'Roboto', sans-serif" }} />
          {search && <button onClick={() => setSearch("")} style={{ background: "none", border: "none", cursor: "pointer", color: M3.onSurfaceVariant, fontSize: 15 }}>✕</button>}
        </div>
      </div>

      {!compact && (
        <div style={{ display: "flex", gap: 7, padding: "4px 16px 6px", overflowX: "auto", scrollbarWidth: "none" }}>
          {FILTERS.map(f => <FilterChip key={f} label={f} active={filter === f} onClick={() => { setFilter(f); setExpanded(null); }} />)}
        </div>
      )}

      <div style={{ display: "flex", gap: 7, padding: compact ? "4px 16px 6px" : "0 16px 8px", overflowX: "auto", scrollbarWidth: "none" }}>
        {[{ l: "Referenze", v: filtered.length }, { l: "Bottiglie", v: totalB }, { l: "Valore", v: `~${totalV}€` }, { l: "Media/ref", v: `~${filtered.length ? Math.round(totalV / filtered.length) : 0}€` }].map(s => (
          <div key={s.l} style={{ flex: "0 0 auto", background: M3.surfaceContainer, borderRadius: 10, padding: compact ? "5px 12px" : "8px 14px", textAlign: "center", minWidth: 68, transition: "padding 0.3s" }}>
            <div style={{ fontSize: compact ? 13 : 15, fontWeight: 700, color: M3.primary, fontFamily: "'Roboto', sans-serif" }}>{s.v}</div>
            <div style={{ fontSize: 9, color: M3.onSurfaceVariant, textTransform: "uppercase", letterSpacing: 0.4, fontFamily: "'Roboto', sans-serif", marginTop: 1 }}>{s.l}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 7, padding: "0 16px 100px" }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 20px", color: M3.onSurfaceVariant }}>
            <div style={{ fontSize: 40, marginBottom: 10 }}>🔍</div>
            <div style={{ fontSize: 15, fontWeight: 500, color: M3.onSurface }}>Nessun vino trovato</div>
          </div>
        ) : filtered.map(wine => (
          <WineCard key={wine.id} wine={wine} expanded={expanded === wine.id}
            onToggle={() => setExpanded(p => p === wine.id ? null : wine.id)}
            onBevi={onBevi} />
        ))}
      </div>
    </>
  );
}

// ─── Tab: Bevuti ──────────────────────────────────────────────────────────────
function TabBevuti({ bevuti, allWines, onRiporta }) {
  const [expanded, setExpanded] = useState(null);
  const wineMap = Object.fromEntries(allWines.map(w => [w.id, w]));
  const totalSpeso = bevuti.reduce((a, b) => a + (wineMap[b.id]?.prezzo || 0), 0);

  if (bevuti.length === 0) {
    return (
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 32, color: M3.onSurfaceVariant }}>
        <div style={{ fontSize: 56, marginBottom: 16 }}>🫗</div>
        <div style={{ fontSize: 18, fontWeight: 500, color: M3.onSurface, marginBottom: 8 }}>Nessun vino bevuto</div>
        <div style={{ fontSize: 14, textAlign: "center", lineHeight: 1.5 }}>Quando segni un vino come bevuto, apparirà qui con data e note.</div>
      </div>
    );
  }

  return (
    <div style={{ padding: "12px 16px 100px", display: "flex", flexDirection: "column", gap: 8 }}>
      <div style={{ background: M3.primaryContainer, borderRadius: 12, padding: "14px 16px", marginBottom: 4 }}>
        <div style={{ fontSize: 11, color: M3.onPrimaryContainer, textTransform: "uppercase", letterSpacing: 0.5, fontFamily: "'Roboto', sans-serif", marginBottom: 6, opacity: 0.8 }}>Archivio degustazioni</div>
        <div style={{ display: "flex", gap: 24 }}>
          <div>
            <div style={{ fontSize: 24, fontWeight: 700, color: M3.onPrimaryContainer, fontFamily: "'Roboto', sans-serif" }}>{bevuti.length}</div>
            <div style={{ fontSize: 11, color: M3.onPrimaryContainer, opacity: 0.8, fontFamily: "'Roboto', sans-serif" }}>bottiglie aperte</div>
          </div>
          <div>
            <div style={{ fontSize: 24, fontWeight: 700, color: M3.onPrimaryContainer, fontFamily: "'Roboto', sans-serif" }}>~{totalSpeso}€</div>
            <div style={{ fontSize: 11, color: M3.onPrimaryContainer, opacity: 0.8, fontFamily: "'Roboto', sans-serif" }}>valore consumato</div>
          </div>
        </div>
      </div>

      {[...bevuti].reverse().map(b => {
        const wine = wineMap[b.id];
        if (!wine) return null;
        const t = TIPO[wine.tipologia] || TIPO["Bianco fermo"];
        const isExp = expanded === b.uid;
        return (
          <div key={b.uid} style={{ borderRadius: 12, border: `1px solid ${M3.outlineVariant}`, background: M3.surfaceContainer, overflow: "hidden" }}>
            <div onClick={() => setExpanded(p => p === b.uid ? null : b.uid)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", cursor: "pointer" }}>
              <div style={{ width: 40, height: 40, borderRadius: 20, background: t.container, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>{t.label}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 10, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", letterSpacing: 0.5, textTransform: "uppercase" }}>{wine.produttore}</div>
                <div style={{ fontSize: 14, fontWeight: 500, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{wine.vino}</div>
                <div style={{ fontSize: 11, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", marginTop: 2 }}>Bevuto il {b.data}</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 2 }}>
                <span style={{ fontSize: 14, fontWeight: 700, color: M3.primary, fontFamily: "'Roboto', sans-serif" }}>~{wine.prezzo}€</span>
                <span style={{ fontSize: 16, color: M3.onSurfaceVariant, transform: isExp ? "rotate(180deg)" : "rotate(0)", transition: "transform 0.2s" }}>⌄</span>
              </div>
            </div>
            {isExp && (
              <div style={{ padding: "0 14px 14px", animation: "expandIn 0.2s ease" }}>
                <div style={{ height: 1, background: M3.outlineVariant, marginBottom: 10 }} />
                {b.nota && (
                  <div style={{ background: M3.surfaceContainerHigh, borderRadius: 8, padding: "10px 12px", marginBottom: 10, borderLeft: `3px solid ${t.indicator}` }}>
                    <div style={{ fontSize: 10, color: M3.onSurfaceVariant, textTransform: "uppercase", letterSpacing: 0.4, fontFamily: "'Roboto', sans-serif", marginBottom: 4 }}>📝 Nota</div>
                    <div style={{ fontSize: 12, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", lineHeight: 1.5 }}>{b.nota}</div>
                  </div>
                )}
                <button onClick={() => onRiporta(b.uid)} style={{ width: "100%", padding: "9px 16px", borderRadius: 20, border: `1px solid ${M3.outline}`, background: "transparent", color: M3.onSurfaceVariant, fontSize: 13, fontWeight: 500, fontFamily: "'Roboto', sans-serif", cursor: "pointer" }}>
                  ↩ Rimetti in cantina
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Tab: Statistiche ─────────────────────────────────────────────────────────
function TabStatistiche({ wines, bevuti }) {
  const bevutiIds = new Set(bevuti.map(b => b.id));
  const cantina = wines.filter(w => !bevutiIds.has(w.id));
  const totB = cantina.reduce((a, w) => a + w.bottiglie, 0);
  const totV = cantina.reduce((a, w) => a + w.prezzo * w.bottiglie, 0);
  const totBevuto = bevuti.reduce((a, b) => { const w = wines.find(x => x.id === b.id); return a + (w?.prezzo || 0); }, 0);
  const swCount = cantina.filter(w => hasCantina(w.produttore)).reduce((a, w) => a + w.bottiglie, 0);

  const byTipo = {};
  cantina.forEach(w => { byTipo[w.tipologia] = (byTipo[w.tipologia] || 0) + w.bottiglie; });
  const tipoEntries = Object.entries(byTipo).sort((a, b) => b[1] - a[1]);
  const maxTipo = Math.max(...tipoEntries.map(([, v]) => v), 1);

  const byProd = {};
  cantina.forEach(w => { byProd[w.produttore] = (byProd[w.produttore] || 0) + w.bottiglie; });
  const topProd = Object.entries(byProd).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const maxProd = Math.max(...topProd.map(([, v]) => v), 1);

  const fasce = { "< 15€": 0, "15–30€": 0, "30–60€": 0, "> 60€": 0 };
  cantina.forEach(w => {
    if (w.prezzo < 15) fasce["< 15€"] += w.bottiglie;
    else if (w.prezzo < 30) fasce["15–30€"] += w.bottiglie;
    else if (w.prezzo < 60) fasce["30–60€"] += w.bottiglie;
    else fasce["> 60€"] += w.bottiglie;
  });

  const Card = ({ children, title }) => (
    <div style={{ background: M3.surfaceContainer, borderRadius: 12, padding: "14px 16px", marginBottom: 10 }}>
      {title && <div style={{ fontSize: 11, color: M3.onSurfaceVariant, textTransform: "uppercase", letterSpacing: 0.5, fontFamily: "'Roboto', sans-serif", marginBottom: 12, fontWeight: 500 }}>{title}</div>}
      {children}
    </div>
  );

  return (
    <div style={{ padding: "12px 16px 100px" }}>
      <Card>
        <div style={{ display: "flex", gap: 8, justifyContent: "space-around", flexWrap: "wrap" }}>
          {[{ l: "Bottiglie", v: totB, s: "in cantina" }, { l: "Valore", v: `~${totV}€`, s: "stimato" }, { l: "Referenze", v: cantina.length }, { l: "Bevuti", v: bevuti.length, s: totBevuto ? `~${totBevuto}€` : "" }].map(s => (
            <div key={s.l} style={{ flex: "1 1 70px", textAlign: "center" }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: M3.primary, fontFamily: "'Roboto', sans-serif" }}>{s.v}</div>
              <div style={{ fontSize: 11, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", fontWeight: 500 }}>{s.l}</div>
              {s.s && <div style={{ fontSize: 10, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif" }}>{s.s}</div>}
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ fontSize: 32 }}>🐌</div>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700, color: "#2E7D32", fontFamily: "'Roboto', sans-serif" }}>{swCount} bottiglie</div>
            <div style={{ fontSize: 12, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif" }}>da cantine premiate Slow Wine 2025</div>
          </div>
        </div>
      </Card>

      <Card title="📊 Distribuzione per tipologia">
        {tipoEntries.map(([tipo, count]) => {
          const t = TIPO[tipo];
          const pct = Math.round((count / totB) * 100);
          return (
            <div key={tipo} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontSize: 13, color: M3.onSurface, fontFamily: "'Roboto', sans-serif" }}>{t?.label} {tipo}</span>
                <span style={{ fontSize: 13, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif" }}>{count} · {pct}%</span>
              </div>
              <div style={{ height: 8, background: M3.surfaceContainerHighest, borderRadius: 4, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${(count / maxTipo) * 100}%`, background: t?.indicator || M3.primary, borderRadius: 4 }} />
              </div>
            </div>
          );
        })}
      </Card>

      <Card title="🏆 Top 5 produttori">
        {topProd.map(([prod, count], i) => (
          <div key={prod} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
            <div style={{ width: 22, height: 22, borderRadius: 11, background: i === 0 ? M3.primaryContainer : M3.surfaceContainerHighest, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: i === 0 ? M3.onPrimaryContainer : M3.onSurfaceVariant, flexShrink: 0 }}>{i + 1}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                <span style={{ fontSize: 13, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {hasCantina(prod) ? "🐌 " : ""}{prod}
                </span>
                <span style={{ fontSize: 12, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif", flexShrink: 0, marginLeft: 6 }}>{count} 🍾</span>
              </div>
              <div style={{ height: 6, background: M3.surfaceContainerHighest, borderRadius: 3, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${(count / maxProd) * 100}%`, background: M3.primary, borderRadius: 3 }} />
              </div>
            </div>
          </div>
        ))}
      </Card>

      <Card title="💰 Fasce di prezzo">
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {Object.entries(fasce).map(([fascia, count]) => (
            <div key={fascia} style={{ flex: "1 1 70px", background: M3.surfaceContainerHigh, borderRadius: 10, padding: "10px 8px", textAlign: "center" }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: M3.primary, fontFamily: "'Roboto', sans-serif" }}>{count}</div>
              <div style={{ fontSize: 11, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", fontWeight: 500 }}>{fascia}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─── App principale ───────────────────────────────────────────────────────────
export default function Cantina() {
  const [tab, setTab] = useState("lista");
  const [bevuti, setBevuti] = useState([]);
  const [extraWines, setExtraWines] = useState([]);
  const [pendingBevi, setPendingBevi] = useState(null);
  const [showAggiungi, setShowAggiungi] = useState(false);
  const [compact, setCompact] = useState(false);
  const [fabVisible, setFabVisible] = useState(true);
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef(null);
  const lastScrollY = useRef(0);

  // ── Carica dati da Supabase all'avvio ──
  useEffect(() => {
    async function loadData() {
      try {
        const [bev, extra] = await Promise.all([
          sb.get("bevuti"),
          sb.get("extra_wines")
        ]);
        setBevuti(bev.map(b => ({ uid: b.uid, id: b.wine_id, data: b.data, nota: b.nota || "" })));
        setExtraWines(extra.map(w => ({ ...w, id: w.id, macerazione: w.macerazione || "—", fermentazione: w.fermentazione || "—", malolattica: w.malolattica || "—" })));
      } catch (e) {
        console.error("Errore caricamento dati:", e);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const allWines = [...WINES_DATA, ...extraWines];

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const y = el.scrollTop;
      setCompact(y > 40);
      setFabVisible(y < lastScrollY.current || y < 60);
      lastScrollY.current = y;
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  const handleBevi = (wineId) => setPendingBevi(allWines.find(w => w.id === wineId));

  const handleConferma = async (nota, data) => {
    const uid = Date.now();
    const row = { uid, wine_id: pendingBevi.id, data, nota: nota || "" };
    setBevuti(prev => [...prev, { uid, id: pendingBevi.id, data, nota: nota || "" }]);
    setPendingBevi(null);
    await sb.insert("bevuti", row);
  };

  const handleRiporta = async (uid) => {
    setBevuti(prev => prev.filter(b => b.uid !== uid));
    await sb.delete("bevuti", "uid", uid);
  };

  const handleSalva = async (form) => {
    const id = Date.now();
    const row = { id, produttore: form.produttore, vino: form.vino, annata: form.annata || "n.d.", tipologia: form.tipologia, bottiglie: form.bottiglie, prezzo: form.prezzo, vitigno: form.vitigno || "", note: form.note || "", macerazione: "—", fermentazione: "—", malolattica: "—" };
    setExtraWines(prev => [...prev, { ...row }]);
    setShowAggiungi(false);
    setTab("lista");
    await sb.insert("extra_wines", row);
  };

  const totBottiglie = allWines.reduce((a, w) => a + w.bottiglie, 0);
  const totValore    = allWines.reduce((a, w) => a + w.prezzo * w.bottiglie, 0);

  if (loading) return (
    <div style={{ height: "100dvh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: M3.surface, gap: 16 }}>
      <div style={{ fontSize: 48 }}>🍷</div>
      <div style={{ fontSize: 16, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif" }}>Carico la cantina…</div>
    </div>
  );

  const NAV = [
    { id: "lista",       icon: "📋", label: "Lista" },
    { id: "bevuti",      icon: "🫗",  label: "Bevuti", badge: bevuti.length },
    { id: "statistiche", icon: "📊", label: "Statistiche" },
  ];

  return (
    <div style={{ height: "100dvh", display: "flex", flexDirection: "column", background: M3.surface, fontFamily: "'Roboto', sans-serif", overflow: "hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        input, textarea, select { outline: none; }
        ::-webkit-scrollbar { width: 0; height: 0; }
        @keyframes expandIn { from { opacity:0; transform:translateY(-5px) } to { opacity:1; transform:translateY(0) } }
        @keyframes slideUp  { from { transform:translateY(100%) } to { transform:translateY(0) } }
      `}</style>

      {/* ── App Bar M3 Medium (collassante) ── */}
      <div style={{
        background: compact ? M3.surfaceContainer : M3.surface,
        boxShadow: compact ? "0 1px 3px rgba(0,0,0,0.09)" : "none",
        transition: "background 0.25s, box-shadow 0.25s",
        flexShrink: 0, zIndex: 10,
      }}>
        {/* Top row */}
        <div style={{ display: "flex", alignItems: "center", height: compact ? 44 : 52, padding: "0 8px 0 4px", transition: "height 0.3s cubic-bezier(0.2,0,0,1)" }}>
          <div style={{ width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🍷</div>
          <div style={{ flex: 1, paddingLeft: 4, overflow: "hidden" }}>
            {compact && (
              <div style={{ fontSize: 16, fontWeight: 500, color: M3.onSurface, fontFamily: "'Roboto', sans-serif", animation: "expandIn 0.2s ease" }}>
                La Mia Cantina
              </div>
            )}
          </div>
          <div style={{ padding: "0 12px", height: 28, borderRadius: 14, background: M3.primaryContainer, color: M3.onPrimaryContainer, display: "flex", alignItems: "center", gap: 5, fontSize: 12, fontWeight: 500, fontFamily: "'Roboto', sans-serif" }}>
            🍾 {totBottiglie} · ~{totValore}€
          </div>
        </div>

        {/* Headline — sparisce quando compact */}
        <div style={{ maxHeight: compact ? 0 : 44, opacity: compact ? 0 : 1, overflow: "hidden", transition: "max-height 0.3s cubic-bezier(0.2,0,0,1), opacity 0.2s", padding: compact ? "0 16px" : "0 16px 10px" }}>
          <div style={{ fontSize: 28, fontWeight: 400, color: M3.onSurface, letterSpacing: -0.5 }}>La Mia Cantina</div>
        </div>

        {/* Sottotitolo tab corrente — solo non-compact */}
        {!compact && tab !== "lista" && (
          <div style={{ padding: "0 16px 10px", fontSize: 14, color: M3.onSurfaceVariant, fontFamily: "'Roboto', sans-serif" }}>
            {tab === "bevuti" ? "Archivio bottiglie aperte" : "Analisi della cantina"}
          </div>
        )}
      </div>

      {/* ── Scrollable content ── */}
      <div ref={scrollRef} style={{ flex: 1, overflowY: "auto" }}>
        {tab === "lista" && <TabLista wines={allWines} bevuti={bevuti} onBevi={handleBevi} onAggiungi={() => setShowAggiungi(true)} compact={compact} />}
        {tab === "bevuti" && <TabBevuti bevuti={bevuti} allWines={allWines} onRiporta={handleRiporta} />}
        {tab === "statistiche" && <TabStatistiche wines={allWines} bevuti={bevuti} />}
      </div>

      {/* ── Extended FAB (solo lista) ── */}
      {tab === "lista" && (
        <div style={{ position: "fixed", bottom: 88, right: 16, zIndex: 20, opacity: fabVisible ? 1 : 0, transform: fabVisible ? "translateY(0) scale(1)" : "translateY(10px) scale(0.92)", transition: "opacity 0.2s, transform 0.2s cubic-bezier(0.2,0,0,1)", pointerEvents: fabVisible ? "auto" : "none" }}>
          <button onClick={() => setShowAggiungi(true)} style={{ display: "flex", alignItems: "center", gap: 8, background: M3.primaryContainer, color: M3.onPrimaryContainer, border: "none", borderRadius: 16, padding: "14px 20px", fontSize: 14, fontWeight: 500, fontFamily: "'Roboto', sans-serif", cursor: "pointer", boxShadow: "0 3px 8px rgba(0,0,0,0.14)" }}>
            <span style={{ fontSize: 18 }}>+</span> Aggiungi vino
          </button>
        </div>
      )}

      {/* ── Navigation Bar M3 ── */}
      <div style={{ height: 80, background: M3.surfaceContainer, flexShrink: 0, borderTop: `1px solid ${M3.outlineVariant}`, display: "flex", alignItems: "flex-start", justifyContent: "space-around", paddingTop: 10, zIndex: 10 }}>
        {NAV.map(nav => (
          <div key={nav.id} onClick={() => setTab(nav.id)} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, cursor: "pointer" }}>
            <div style={{ position: "relative" }}>
              <div style={{ width: 64, height: 32, borderRadius: 16, background: tab === nav.id ? M3.secondaryContainer : "transparent", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, transition: "background 0.2s" }}>
                {nav.icon}
              </div>
              {nav.badge > 0 && (
                <div style={{ position: "absolute", top: -2, right: 6, minWidth: 16, height: 16, borderRadius: 8, background: M3.primary, color: M3.onPrimary, fontSize: 10, fontWeight: 700, fontFamily: "'Roboto', sans-serif", display: "flex", alignItems: "center", justifyContent: "center", padding: "0 4px" }}>
                  {nav.badge}
                </div>
              )}
            </div>
            <span style={{ fontSize: 12, fontFamily: "'Roboto', sans-serif", fontWeight: tab === nav.id ? 700 : 400, color: tab === nav.id ? M3.onSecondaryContainer : M3.onSurfaceVariant, letterSpacing: 0.3 }}>
              {nav.label}
            </span>
          </div>
        ))}
      </div>

      {/* ── Modals ── */}
      {pendingBevi && <ModalBevi wine={pendingBevi} onConferma={handleConferma} onAnnulla={() => setPendingBevi(null)} />}
      {showAggiungi && <ModalAggiungi onSalva={handleSalva} onAnnulla={() => setShowAggiungi(false)} />}
    </div>
  );
}
